
let Button = document.getElementById("toggle")
let Menu = document.getElementById("menu")
let Toggle = document.getElementById("tgl")
let MenuContent = document.getElementById("menutgl")
let MenuBack = document.getElementById("cancel")

function toggled(){
  MenuContent.style.display = 'block'
  MenuContent.style.display = 'flex'
  MenuContent.style.flexDirection = 'column'
}
function cancel(){
  MenuContent.style.display = 'none'
}


let FirstImage = document.getElementById('img1')

let SecondImage = document.getElementById('img2')

let ThirdImage = document.getElementById('img3')

let FourthImage = document.getElementById('img4')



function image1hover(){
  FirstImage.style.backgroundColor = 'white'
}
function image2hover(){
  SecondImage.style.backgroundColor = 'white'
}
function image3hover(){
  ThirdImage.style.backgroundColor = 'white'
}
function image4hover(){
  FourthImage.style.backgroundColor = 'white'
}
function img1hover(){
  FirstImage.style.backgroundColor = ' rgb(211, 211, 211)'
}
function img2hover(){
  SecondImage.style.backgroundColor = ' rgb(211, 211, 211)'
}
function img3hover(){
  ThirdImage.style.backgroundColor = ' rgb(211, 211, 211)'
}
function img4hover(){
  FourthImage.style.backgroundColor = ' rgb(211, 211, 211)'
}


let Main = document.getElementById("main")

let Email = document.getElementById("email")

let retypePassword = document.getElementById("reType")

let Password = document.getElementById("password")

let FirstName = document.getElementById("name")

let LastName = document.getElementById("nametwo")

let MaleSelect = document.getElementById("male")

let FemaleSelect = document.getElementById("female")

let Offers = document.getElementById("country")

let registration = document.getElementById('reg')

let errorMessage = document.getElementById('error')

registration.addEventListener('click', (e)=>{
  if(Email.value===''){
   document.getElementById("p1").innerHTML = "Please enter your email"
    document.getElementById("p1").style.color = "red"
    document.getElementById("p1").style.marginTop = "0px"
    document.getElementById("p1").style.marginRight = "120px"
   } if(Password.value === '' || password < 8){
    document.getElementById("p2").innerHTML = "<p> please enter password</p>"
    document.getElementById("p2").style.color = "red"
    document.getElementById("p2").style.marginTop = "-5px"
    document.getElementById("p2").style.marginRight = "120px"
   } if(retypePassword.value != password.value){
    document.getElementById("p3").innerHTML = "<p> Password does not match</p>"
     document.getElementById("p3").style.color = "red"
     document.getElementById("p3").style.marginTop = "-20px"
     document.getElementById("p3").style.marginRight = "160px"
   } if(FirstName.value === ''){
    document.getElementById("p4").innerHTML = "<p> please enter your First Name</p>"
    document.getElementById("p4").style.color = "red"
    document.getElementById("p4").style.marginTop = "15px"
    document.getElementById("p4").style.marginLeft = "-450px"
   }if(LastName.value === ''){
    document.getElementById("p5").innerHTML = "<p> please enter your Last Name</p>"
    document.getElementById("p5").style.color = "red"
    document.getElementById("p5").style.marginTop = "-105px"
    document.getElementById("p5").style.marginLeft = "250px"
   } if(retypePassword.value != password.value || Email.value==='' || FirstName.value === '' || LastName.value === ''){
    errorMessage.innerHTML = "Something went wrong, please check your form."
    errorMessage.style.color = "red"
    errorMessage.style.marginRight = "150px"
   }
   else{
      alert('congratulations')
      
      location.reload()
    }
    e.preventDefault()
  })

  function MoreOne(){
    
  let dots = document.getElementById("dots")
  let moreText = document.getElementById("moreone")
  let btnText = document.getElementById("mybtnone")

  if (dots.style.display === "none"){
      dots.style.display = "inline";
      btnText.innerHTML = "Read More";
      moreText.style.display = "none";
  }else {
      dots.style.display = "none";
      btnText.innerHTML = "Read less";
      moreText.style.display = "inline";
    }
  }
  function MoreTwo(){
    
  let Dots = document.getElementById("dotstwo")
  let MoreText = document.getElementById("moretwo")
  let BtnText = document.getElementById("mybtntwo")

  if (Dots.style.display === "none"){
      Dots.style.display = "inline";
      BtnText.innerHTML = "Read More";
      MoreText.style.display = "none";
  }else {
      Dots.style.display = "none";
      BtnText.innerHTML = "Read less";
      MoreText.style.display = "inline";
    }
  }
  function MoreThree(){
    
  let Dot = document.getElementById("dotsthree")
  let Moretext = document.getElementById("morethree")
  let Btntext = document.getElementById("mybtnthree")

  if (Dot.style.display === "none"){
      Dot.style.display = "inline";
      Btntext.innerHTML = "Read More";
      Moretext.style.display = "none";
  }else {
      Dot.style.display = "none";
      Btntext.innerHTML = "Read less";
      Moretext.style.display = "inline";
    }
  }